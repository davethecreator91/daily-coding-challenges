# What is this?

Original source files for assets (vector, PSD, PXD, etc) should be kept in this directory (`originals`) when they are available. Final files used in any content should *not* be stored in this directory, but instead in the `assets` directory one level above this.
