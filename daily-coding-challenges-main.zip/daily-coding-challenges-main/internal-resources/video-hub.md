# ![Video Hub](../assets/video-hub.png)

Here you'll find the outlines and the assets used in video content, as well as the original and final video content. Notes to help record specific content can also be found here, when applicable.

## Video content

🪨 [Originals](https://drive.google.com/drive/u/0/folders/1WVKYWq8LYPjPDj3CEJgmNYb48H9JnOZK)

💎 [Finals](https://generalassembly.wistia.com/folders/8nsa0pby34)
