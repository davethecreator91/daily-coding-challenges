# ![Instructor Guide](../assets/instructor-guide.png)

🏗️ **Under Construction**

We are constantly working to improve our resources for instructors and students.

**Have something to contribute to this Instructor Guide?** [Let us know](https://git.generalassemb.ly/modular-curriculum-all-courses/TEMPLATE-Lab-Solution-Code-Module).
