# ![Release Notes](../assets/release-notes.png)

## Version 1.0 - Updates from legacy content

This release modularizes the legacy Daily Code Challenges lecture and provides some other minor updates detailed below. Updates are provided here at the module level, but all subsequent updates should be documented at the lesson level.

### Release details

#### Additions

This release adds video references as additional solution aids. 






